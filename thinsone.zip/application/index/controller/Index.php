<?php
namespace app\index\controller;

class Index
{
    public function index()
    {
        echo '1111111111';
    }
}
