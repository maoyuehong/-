<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:66:"D:\WWW\thinsone\public/../application/admin\view\role\add.html";i:1507526354;}*/ ?>
<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from www.zi-han.net/theme/hplus/login_v2.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 20 Jan 2016 14:19:49 GMT -->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">

    <title> 登录</title>
    <meta name="keywords" content="H+后台主题,后台bootstrap框架,会员中心主题,后台HTML,响应式后台">
    <meta name="description" content="H+是一个完全响应式，基于Bootstrap3最新版本开发的扁平化主题，她采用了主流的左右两栏式布局，使用了Html5+CSS3等现代技术">
    <link href="/static/admin/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/admin/css/font-awesome.min93e3.css?v=4.4.0" rel="stylesheet">
    <link href="/static/admin/css/animate.min.css" rel="stylesheet">
    <link href="/static/admin/css/style.min.css" rel="stylesheet">
    <link href="/static/admin/css/login.min.css" rel="stylesheet">

    <!--[if lt IE 9]>
    <meta http-equiv="refresh" content="0;ie.html" />

    <![endif]-->
    <script>
        if(window.top!==window.self){window.top.location=window.location};
    </script>

</head>

<body class="signin">
<div class="signinpanel">
    <div class="row">
        <div class="col-sm-7">
            <div class="signin-info">
                <div class="logopanel m-b">
                    <h1>[ H+ ]</h1>
                </div>
                <div class="m-b"></div>
                <h4> <strong></strong></h4>

            </div>
        </div>
        <div class="col-sm-5">

            <h4 class="no-margins"></h4>
            <p class="m-t-md"></p>
            <input type="text" class="form-control uname" placeholder="用户名" name="username" id="username"/>
            <input type="password" class="form-control pword m-b" placeholder="密码"  name="password"  id="password"/>
            <a href="#"></a><span id="sendresult"></span>
            <input type="submit" class="btn btn-success btn-block" value="添加" onclick="login()">

        </div>
    </div>
    <div class="signup-footer">
        <div class="pull-left">
            &copy; 2015 All Rights Reserved. H+
        </div>
    </div>
</div>
</body>
<script type="text/javascript" src="/static/admin/js/jquery-1.8.2.min.js"></script>
<script type="text/javascript" src="/static/admin/layer/layer.js"></script>
<!--<script type="text/javascript" src="/static/admin/layer/theme/default/layer.css"></script>-->

<script type="text/javascript">
    function login(){
        //layer.alert('111111111',{icon:6});
        var username=$('[name=username]').val();
        var password=$('[name=password]').val();
        $.ajax({
            type:'post',
            url:'/admin/role/tianjia',
            dataType:'json',
            data:{
                'username':username,
                'password':password,
            },
            success:function(ret){
                //console.log(ret);
                if(ret.status==0){
                    // $('#sendresult').html(ret['msg']);
                    //window.location.href = '/admin/lesson/index';
                    //alert(ret['msg']);
                    layer.alert(ret['msg'],{icon:6},function(){
                        //window.location.href = '/admin/lesson/index';
                    })
                    $('.layui-layer-content').css('color','#11CD6D');

                }else{
                    //alert(11111);
                    //$('#sendresult').html(ret['msg']);
                    layer.alert(ret['msg'],{icon:5});
                    $('.layui-layer-content').css('color','red');
                }
            }
        })
    }
</script>

<!-- Mirrored from www.zi-han.net/theme/hplus/login_v2.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 20 Jan 2016 14:19:52 GMT -->
</html>
