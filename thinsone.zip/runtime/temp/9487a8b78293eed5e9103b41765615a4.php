<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:68:"D:\WWW\thinsone\public/../application/admin\view\lesson\upd.html";i:1508122852;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="renderer" content="webkit">
    <meta http-equiv="Cache-Control" content="no-siteapp" />
    <link rel="icon" type="image/png" href="/static/admin/images/icon.png">
    <link href="/static/admin/css/bootstrap.min14ed.css?v=3.3.6" rel="stylesheet">
    <link href="/static/admin/css/font-awesome.min93e3.css?v=4.4.0" rel="stylesheet">
    <link href="/static/admin/css/animate.min.css" rel="stylesheet">
    <link href="/static/admin/css/style.min862f.css?v=4.1.0" rel="stylesheet">
</head>
<body>
<div class="wrapper wrapper-content animated fadeInRight">
    <div class="form-horizontal m-t">
        <div class="form-group">
            <label class="col-sm-3 control-label">昵称：</label>
            <div class="col-sm-8">
                <input type="text" id="nickname" class="form-control" placeholder="请输入昵称" value="<?php echo $info['a_nickname']; ?>">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">用户名：</label>
            <div class="col-sm-8">
                <input type="text" id="name" class="form-control" placeholder="请输入用户名" value="<?php echo $info['a_name']; ?>">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">密码：</label>
            <div class="col-sm-8">
                <input type="password" id="password" class="form-control" placeholder="请输入登录密码">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">确认密码：</label>
            <div class="col-sm-8">
                <input type="password" id="password_two" class="form-control" placeholder="请输入确认密码">
                <span class="help-block m-b-none">
						<i class="fa fa-info-circle"></i> 密码由字母、数字和标点符号组成（至少5位-20位）
					</span>
            </div>
        </div>
        <?php if($info['a_id'] != 1 and $admin_session['id'] == 1): ?>
            <div class="form-group">
                <label class="col-sm-3 control-label">选择权限：</label>
                <div class="col-sm-8">
                    <foreach name="admin_qx" item="vo">
                        <div class="permission-list">
                            <div class="checkbox">
                                <label>
                                    <input type="checkbox" class="checkbox"><?php echo $vo['name']; ?>
                                </label>
                            </div>　　
                            <?php if(is_array($vo['sub_button']) || $vo['sub_button'] instanceof \think\Collection || $vo['sub_button'] instanceof \think\Paginator): if( count($vo['sub_button'])==0 ) : echo "" ;else: foreach($vo['sub_button'] as $key=>$v): ?>
                                <label class="checkbox-inline">
                                    <input type="checkbox" class="checkbox" <?php if(in_array($v['key'],explode(',',$info['a_list']))): ?>checked="checked"<?php endif; ?> value="<?php echo $v['key']; ?>"><?php echo $v['name']; ?>
                                </label>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </div>
                        <div class="hr-line-dashed"></div>
                    {/foreach}
                </div>
            </div>
        <?php endif; ?>
        <div class="form-group">
            <div class="col-sm-8 col-sm-offset-3">
                <button class="btn btn-primary" type="button" onClick="submit('<?php echo $info['a_id']; ?>');">提交</button>
            </div>
        </div>
    </div>
</div>
<script src="/static/admin/js/jquery.min.js?v=2.1.4"></script>
<script src="/static/admin/js/layer.js"></script>
<script type="text/javascript">
    $(function(){
        $(".permission-list .checkbox input:checkbox").click(function(){
            $(this).parent().parent().parent().find(".checkbox-inline input:checkbox").prop("checked",$(this).prop("checked"));
        });
    });
    var click = true;
    function submit(id){
        if(click){
            click = false;
            var nickname = $('#nickname').val();
            var name = $('#name').val();
            var password = $('#password').val();
            var password_two = $('#password_two').val();
            var list = "";
            $(".checkbox-inline input:checkbox:checked").each(function(index){
                if(index == 0){
                    list += $(this).val();
                }else{
                    list += ","+$(this).val();
                }
            });
            $.post("__URL__/admin",{switch_case:1,id:id,nickname:nickname,name:name,password:password,password_two:password_two,list:list},
                function(data){
                    if(data.fal){
                        layer.msg(data.content, {icon: 1,time: 2000});
                    }else{
                        layer.msg(data.content, {icon: 2,time: 2000});
                    }
                    click = true;
                });
        }
    }
</script>
</body>
</html>
